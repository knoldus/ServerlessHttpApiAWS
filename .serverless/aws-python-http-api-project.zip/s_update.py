import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='vaibhavkuma779',
    application_name='aws-http',
    app_uid='Td6gj99xT74ztsKbBW',
    org_uid='71d0ddb1-234c-45d7-a720-21572ce55985',
    deployment_uid='6c8eac66-1411-4e8a-9cb7-aab7be3b960e',
    service_name='aws-python-http-api-project',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='6.2.2',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'aws-python-http-api-project-dev-update', 'timeout': 10}
try:
    user_handler = serverless_sdk.get_user_handler('handler.update')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
